import { Component } from '@angular/core';

@Component({
  selector: 'app-zero-config',
  templateUrl: 'zero-config.component.html'
})
export class ZeroConfigComponent {
}
