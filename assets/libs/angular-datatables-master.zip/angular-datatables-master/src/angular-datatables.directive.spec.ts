/**
 * @license
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://raw.githubusercontent.com/l-lin/angular-datatables/master/LICENSE
 */

import { DataTableDirective } from './angular-datatables.directive';

describe('Directive: Datatable', () => {
  it('should create an instance', () => {
    // let directive = new DataTable(null);
    // expect(directive).toBeTruthy();
  });
});
